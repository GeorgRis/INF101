package no.uib.inf101.logic;

public class Board {
    private final int SIZE = 4;
    private Tile[][] tiles;

    public Board() {
        tiles = new Tile[SIZE][SIZE];
        initBoard();

    }

    private void initBoard() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                tiles[i][j] = null;
            }
        }
    }

    public Tile getTile(int row, int col) {
        return tiles[row][col];
    }

    public void setTile(int row, int col, Tile tile) {
        tiles[row][col] = tile;
    }

    public int getSize() {
        return SIZE;
    }
}

