package no.uib.inf101.sample;

/**
 * Hello world!
 */
public class Main {

	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
	
}
