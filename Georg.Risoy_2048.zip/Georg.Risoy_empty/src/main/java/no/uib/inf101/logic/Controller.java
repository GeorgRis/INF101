package no.uib.inf101.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Controller {
    private Board board;
    private Random random = new Random();
    private int score = 0;

    public Controller(Board board) {
        this.board = board;
        spawnNewTile();
        spawnNewTile();
    }

    public void move(String direction) {
        if (isGameOver()) return;

        Tile[][] oldTiles = copyBoard();
        String dir = direction.toLowerCase();
        switch (dir) {
            case "up" -> moveUp();
            case "down" -> moveDown();
            case "left" -> moveLeft();
            case "right" -> moveRight();
        }
        if (!boardsEqual(oldTiles, board)) {
            spawnNewTile();
        }
    }

    public int getScore() {
        return score;
    }

    public boolean isGameOver() {
        int size = board.getSize();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Tile current = board.getTile(i, j);
                if (current == null) return false;
                if (i < size - 1) {
                    Tile down = board.getTile(i + 1, j);
                    if (down != null && current.getValue() == down.getValue()) return false;
                }
                if (j < size - 1) {
                    Tile right = board.getTile(i, j + 1);
                    if (right != null && current.getValue() == right.getValue()) return false;
                }
            }
        }
        return true;
    }

    private void moveLeft() {
        int size = board.getSize();
        for (int i = 0; i < size; i++) {
            List<Tile> row = new ArrayList<>();
            for (int j = 0; j < size; j++) {
                Tile t = board.getTile(i, j);
                if (t != null) row.add(new Tile(t.getValue()));
            }
            List<Tile> merged = mergeTiles(row);
            for (int j = 0; j < size; j++) {
                board.setTile(i, j, j < merged.size() ? merged.get(j) : null);
            }
        }
    }

    private void moveRight() {
        int size = board.getSize();
        for (int i = 0; i < size; i++) {
            List<Tile> row = new ArrayList<>();
            for (int j = size - 1; j >= 0; j--) {
                Tile t = board.getTile(i, j);
                if (t != null) row.add(new Tile(t.getValue()));
            }
            List<Tile> merged = mergeTiles(row);
            for (int j = size - 1, k = 0; j >= 0; j--, k++) {
                board.setTile(i, j, k < merged.size() ? merged.get(k) : null);
            }
        }
    }

    private void moveUp() {
        int size = board.getSize();
        for (int j = 0; j < size; j++) {
            List<Tile> col = new ArrayList<>();
            for (int i = 0; i < size; i++) {
                Tile t = board.getTile(i, j);
                if (t != null) col.add(new Tile(t.getValue()));
            }
            List<Tile> merged = mergeTiles(col);
            for (int i = 0; i < size; i++) {
                board.setTile(i, j, i < merged.size() ? merged.get(i) : null);
            }
        }
    }

    private void moveDown() {
        int size = board.getSize();
        for (int j = 0; j < size; j++) {
            List<Tile> col = new ArrayList<>();
            for (int i = size - 1; i >= 0; i--) {
                Tile t = board.getTile(i, j);
                if (t != null) col.add(new Tile(t.getValue()));
            }
            List<Tile> merged = mergeTiles(col);
            for (int i = size - 1, k = 0; i >= 0; i--, k++) {
                board.setTile(i, j, k < merged.size() ? merged.get(k) : null);
            }
        }
    }

    private List<Tile> mergeTiles(List<Tile> tiles) {
        List<Tile> merged = new ArrayList<>();
        int i = 0;
        while (i < tiles.size()) {
            if (i < tiles.size() - 1 && tiles.get(i).getValue() == tiles.get(i + 1).getValue()) {
                int newVal = tiles.get(i).getValue() * 2;
                merged.add(new Tile(newVal));
                score += newVal;
                i += 2;
            } else {
                merged.add(new Tile(tiles.get(i).getValue()));
                i++;
            }
        }
        return merged;
    }

    private void spawnNewTile() {
        List<int[]> empty = new ArrayList<>();
        int size = board.getSize();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (board.getTile(i, j) == null) {
                    empty.add(new int[] { i, j });
                }
            }
        }
        if (!empty.isEmpty()) {
            int[] pos = empty.get(random.nextInt(empty.size()));
            board.setTile(pos[0], pos[1], new Tile(random.nextDouble() < 0.9 ? 2 : 4));
        }
    }

    private Tile[][] copyBoard() {
        int size = board.getSize();
        Tile[][] copy = new Tile[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Tile t = board.getTile(i, j);
                if (t != null) {
                    copy[i][j] = new Tile(t.getValue());
                } else {
                    copy[i][j] = null;
                }
            }
        }
        return copy;
    }

    private boolean boardsEqual(Tile[][] boardArray, Board boardObj) {
        int size = boardObj.getSize();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Tile t1 = boardArray[i][j];
                Tile t2 = boardObj.getTile(i, j);
                if (t1 == null && t2 == null) continue;
                if (t1 == null || t2 == null) return false;
                if (t1.getValue() != t2.getValue()) return false;
            }
        }
        return true;
    }
} 
