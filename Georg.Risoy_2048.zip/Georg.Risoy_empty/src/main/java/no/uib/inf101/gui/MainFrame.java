package no.uib.inf101.gui;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import no.uib.inf101.logic.Board;
import no.uib.inf101.logic.Controller;

public class MainFrame extends JFrame{
    private GamePanel gamePanel;
    private Controller controller;

    public MainFrame() {
        setTitle("2048");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);

        Board board = new Board();
        controller = new Controller(board);

        gamePanel = new GamePanel(controller, board); // sett feltet riktig
        add(gamePanel);
        

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int keyCode = e.getKeyCode();
                switch (keyCode) {
                    case KeyEvent.VK_UP -> controller.move("UP");
                    case KeyEvent.VK_DOWN -> controller.move("DOWN");
                    case KeyEvent.VK_LEFT -> controller.move("LEFT");
                    case KeyEvent.VK_RIGHT -> controller.move("RIGHT");
                }
                
                gamePanel.repaint();

                if (controller.isGameOver()) {
                    JOptionPane.showMessageDialog(null, "Game Over");
                }
            }
        });

        setVisible(true);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainFrame::new);
    }
    
}
