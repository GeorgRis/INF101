package no.uib.inf101.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JPanel;

import no.uib.inf101.logic.Board;
import no.uib.inf101.logic.Controller;
import no.uib.inf101.logic.Tile;

public class GamePanel extends JPanel {
    private final Controller controller;
    private final Board board;
    private final int TILE_SIZE = 100;
    private final int TILE_MARGIN = 16;

    public GamePanel(Controller controller, Board board) {
        this.controller = controller;
        this.board = board;
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP -> controller.move("up");
                    case KeyEvent.VK_DOWN -> controller.move("down");
                    case KeyEvent.VK_LEFT -> controller.move("left");
                    case KeyEvent.VK_RIGHT -> controller.move("right");
                }
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Bakgrunn
        g2d.setColor(new Color(0xbbada0));
        g2d.fillRect(0, 0, getWidth(), getHeight());

        // Tegn alle tiles
        for (int i = 0; i < board.getSize(); i++) {
            for (int j = 0; j < board.getSize(); j++) {
                drawTile(g2d, board.getTile(i, j), j, i);
            }
        }

        // Score
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("SansSerif", Font.BOLD, 20));
        g2d.drawString("Score: " + controller.getScore(), 20, 30);

        // Game over
        if (controller.isGameOver()) {
            g2d.setColor(new Color(255, 0, 0, 180));
            g2d.setFont(new Font("SansSerif", Font.BOLD, 48));
            g2d.drawString("Game Over", 50, getHeight() / 2);
        }
    }

    private void drawTile(Graphics2D g, Tile tile, int x, int y) {
        int value = tile != null ? tile.getValue() : 0;
        int xOffset = offsetCoors(x);
        int yOffset = offsetCoors(y);

        g.setColor(getTileColor(value));
        g.fillRoundRect(xOffset, yOffset, TILE_SIZE, TILE_SIZE, 14, 14);

        g.setColor(value < 16 ? new Color(0x776e65) : new Color(0xf9f6f2));
        Font font = new Font("SansSerif", Font.BOLD, 36);
        g.setFont(font);

        if (value != 0) {
            String s = String.valueOf(value);
            FontMetrics fm = getFontMetrics(font);
            int w = fm.stringWidth(s);
            int h = -(int) fm.getLineMetrics(s, g).getBaselineOffsets()[2];
            g.drawString(s, xOffset + (TILE_SIZE - w) / 2, yOffset + TILE_SIZE / 2 + h / 2);
        }
    }

    private int offsetCoors(int arg) {
        return arg * (TILE_MARGIN + TILE_SIZE) + TILE_MARGIN;
    }

    private Color getTileColor(int value) {
        return switch (value) {
            case 2 -> new Color(0xeee4da);
            case 4 -> new Color(0xede0c8);
            case 8 -> new Color(0xf2b179);
            case 16 -> new Color(0xf59563);
            case 32 -> new Color(0xf67c5f);
            case 64 -> new Color(0xf65e3b);
            case 128 -> new Color(0xedcf72);
            case 256 -> new Color(0xedcc61);
            case 512 -> new Color(0xedc850);
            case 1024 -> new Color(0xedc53f);
            case 2048 -> new Color(0xedc22e);
            default -> new Color(0xcdc1b4);
        };
    }
}
