# Empty Java Project
This repository contains an empty Java project which you can use for anything :) 
